exports.handler = async function (event) {
  const { username, groupId } = event.queryStringParameters || {};

  if (!username || !groupId) {
    return respond(400, { error: "Missing username or groupId" });
  }

  try {
    // Step 1: resolve username -> userId
    const userRes = await fetch("https://users.roblox.com/v1/usernames/users", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ usernames: [username], excludeBannedUsers: false }),
    });
    const userData = await userRes.json();
    const user = userData.data?.[0];
    if (!user) return respond(404, { error: "User not found" });

    // Step 2: get groups/roles for user
    const groupRes = await fetch(
      `https://groups.roblox.com/v2/users/${user.id}/groups/roles`
    );
    const groupData = await groupRes.json();

    const membership = groupData.data?.find(
      (entry) => entry.group.id === parseInt(groupId)
    );

    if (!membership) {
      return respond(200, {
        userId: user.id,
        username: user.name,
        inGroup: false,
        rank: 0,
        role: "None",
      });
    }

    return respond(200, {
      userId: user.id,
      username: user.name,
      inGroup: true,
      rank: membership.role.rank,
      role: membership.role.name,
    });
  } catch (err) {
    return respond(500, { error: "Internal error: " + err.message });
  }
};

function respond(statusCode, body) {
  return {
    statusCode,
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
    },
    body: JSON.stringify(body),
  };
}
